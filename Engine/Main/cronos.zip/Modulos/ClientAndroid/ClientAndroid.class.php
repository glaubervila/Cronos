<?php
/**
 * @package  :ClientAndroid
 * @name     :ClientAndroid
 * @class    :ClientAndroid.class.php
 * @author   :Glauber Costa Vila-Verde
 * @date     :12/03/2013
 * @Diretorio:Main/Modulos/ClientAndroid/
 * Classe Responsavel por disponibilizar as informacoes do via json para o client Android
 */

class ClientAndroid {


    /** getVendedores()
     * Retorna um lista com o id e o nome dos usuarios cadastrados no grupo vendedores
     * @return: array() de obj vendedores com
     * $id: chave do vendedor
     * $nome: nome do vendedor
     */
    public function getVendedores($data){

        $grupo_vendedores = Common::getParametro("chave_vendedores");

        $vendedores = Usuarios::getUsuarioByGrupo($grupo_vendedores, false);

        $result = new StdClass();

        if (count($vendedores) > 0){
            $result->success = true;
            $result->rows = $vendedores;
        }
        else {
            $result->success = false;
        }
        echo json_encode($result);
    }


}